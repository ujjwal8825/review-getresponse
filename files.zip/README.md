# Email Platform Review

Static GetResponse review site. Edit the config at the bottom of index.html.
